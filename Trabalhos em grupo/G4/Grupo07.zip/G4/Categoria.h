#ifndef CATEGORIA_H
#define CATEGORIA_H

const int TODOS = 0;
const int PINTURA = 1;
const int ESCULTURA = 2;

#endif /* CATEGORIA_H */
